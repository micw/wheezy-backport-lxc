var searchData=
[
  ['clear_5fconfig',['clear_config',['../structlxc__container.html#aad7035180db1050f9dfd6f7f6f008c9f',1,'lxc_container']]],
  ['clear_5fconfig_5fitem',['clear_config_item',['../structlxc__container.html#a78d86ced72bfb276b9fa1634b5eedd16',1,'lxc_container']]],
  ['clone',['clone',['../structlxc__container.html#a9da41d5919319b80ea1744b444f01677',1,'lxc_container']]],
  ['comment_5fpathname',['comment_pathname',['../structlxc__snapshot.html#aed1a8c6216b382c5574c0d31c4e913a1',1,'lxc_snapshot']]],
  ['config_5ffile_5fname',['config_file_name',['../structlxc__container.html#aaaf338836d323c7f97ff53e9c03e2dfe',1,'lxc_container']]],
  ['config_5fpath',['config_path',['../structlxc__container.html#a7244de1a9590f9650bf75b23f1fce0ee',1,'lxc_container']]],
  ['console',['console',['../structlxc__container.html#a222a64610d5db88f36c8b054e3d45a33',1,'lxc_container']]],
  ['console_5fgetfd',['console_getfd',['../structlxc__container.html#acf237c8d2e6dbe335c5670d56c30c8d7',1,'lxc_container']]],
  ['container_5fdisk_5flock',['container_disk_lock',['../lxclock_8h.html#a90136288ceedfdbeedd773d58f6d0c9d',1,'lxclock.h']]],
  ['container_5fdisk_5funlock',['container_disk_unlock',['../lxclock_8h.html#a44b530e648e20a119ffe863fe237d0cf',1,'lxclock.h']]],
  ['container_5fmem_5flock',['container_mem_lock',['../lxclock_8h.html#ad1e0d9777a993b9e3dcde40f415adbc9',1,'lxclock.h']]],
  ['container_5fmem_5funlock',['container_mem_unlock',['../lxclock_8h.html#a2f773be1b0e34bcf433a8e584b014f51',1,'lxclock.h']]],
  ['create',['create',['../structlxc__container.html#aa7ed864c0494df67fe7cce42bb79fc7d',1,'lxc_container']]],
  ['createl',['createl',['../structlxc__container.html#a3c8b4609067b7d4fc770688b9c069ace',1,'lxc_container']]]
];
