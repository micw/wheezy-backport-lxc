var searchData=
[
  ['daemonize',['daemonize',['../structlxc__container.html#aad6d903f5f22937f0662814ee4c1ac05',1,'lxc_container']]],
  ['destroy',['destroy',['../structlxc__container.html#a1441b3a58810bf50d23dc57c0663a336',1,'lxc_container']]],
  ['dir',['dir',['../structbdev__specs.html#a9fb5bd81f51ffefeff5a94ce6edf5dbb',1,'bdev_specs']]]
];
