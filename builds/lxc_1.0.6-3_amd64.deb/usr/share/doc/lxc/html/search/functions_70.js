var searchData=
[
  ['process_5flock',['process_lock',['../lxclock_8h.html#a63d23614728c4635d2fa6f2aa5dcad70',1,'lxclock.h']]],
  ['process_5funlock',['process_unlock',['../lxclock_8h.html#ad8c01a6678bf87a5b9c0fd57021ff4c7',1,'lxclock.h']]]
];
