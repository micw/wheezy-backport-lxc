var searchData=
[
  ['lxc_5fattach_5flsm',['LXC_ATTACH_LSM',['../attach__options_8h.html#a50a65f51aade111bb87698dd6a1c31ca',1,'attach_options.h']]],
  ['lxc_5fattach_5foptions_5fdefault',['LXC_ATTACH_OPTIONS_DEFAULT',['../attach__options_8h.html#ac5bf0ac8ff84c53763ca6f38d797f5ef',1,'attach_options.h']]],
  ['lxc_5fclone_5fkeepbdevtype',['LXC_CLONE_KEEPBDEVTYPE',['../lxccontainer_8h.html#abece303499457d96fbec3e1e4a32ab53',1,'lxccontainer.h']]],
  ['lxc_5fclone_5fkeepmacaddr',['LXC_CLONE_KEEPMACADDR',['../lxccontainer_8h.html#af9fe65e995db6d7636fba0a445b0dd51',1,'lxccontainer.h']]],
  ['lxc_5fclone_5fkeepname',['LXC_CLONE_KEEPNAME',['../lxccontainer_8h.html#a0706477b07c3973f038c7e1ffb1c0a3b',1,'lxccontainer.h']]],
  ['lxc_5fclone_5fmaxflags',['LXC_CLONE_MAXFLAGS',['../lxccontainer_8h.html#aaac57be1a436d7eda5bca4253c505c92',1,'lxccontainer.h']]],
  ['lxc_5fclone_5fmaybe_5fsnapshot',['LXC_CLONE_MAYBE_SNAPSHOT',['../lxccontainer_8h.html#a2bbfe00418b0a5f1d2f0240c6b27cc30',1,'lxccontainer.h']]],
  ['lxc_5fclone_5fsnapshot',['LXC_CLONE_SNAPSHOT',['../lxccontainer_8h.html#a4856a9313653380f71620208c31d516b',1,'lxccontainer.h']]],
  ['lxc_5fcreate_5fmaxflags',['LXC_CREATE_MAXFLAGS',['../lxccontainer_8h.html#a132fa83c249f7d65bccf4f5d4cc629f7',1,'lxccontainer.h']]],
  ['lxc_5fcreate_5fquiet',['LXC_CREATE_QUIET',['../lxccontainer_8h.html#aa9a2225bffde6f298e7d412ec5f71d11',1,'lxccontainer.h']]],
  ['lxc_5flock_5fanon_5fsem',['LXC_LOCK_ANON_SEM',['../lxclock_8h.html#a3e1f4bf533680b839d7bc11eeb027c07',1,'lxclock.h']]],
  ['lxc_5flock_5fflock',['LXC_LOCK_FLOCK',['../lxclock_8h.html#aa0e1ec4164635c87eeb1c8f2021b8200',1,'lxclock.h']]]
];
