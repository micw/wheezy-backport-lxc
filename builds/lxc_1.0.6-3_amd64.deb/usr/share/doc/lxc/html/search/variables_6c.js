var searchData=
[
  ['load_5fconfig',['load_config',['../structlxc__container.html#a55798d1efdb0896b6e229f6b333da363',1,'lxc_container']]],
  ['lv',['lv',['../structbdev__specs.html#aa6a21f8e80f7e9632ec3714a8c23f0de',1,'bdev_specs']]],
  ['lxcpath',['lxcpath',['../structlxc__snapshot.html#a8a1c6d051b7350e96ad0fd51fab547e6',1,'lxc_snapshot']]]
];
