var searchData=
[
  ['lxc_5fattach_5fcommand_5ft',['lxc_attach_command_t',['../structlxc__attach__command__t.html',1,'']]],
  ['lxc_5fattach_5foptions_5ft',['lxc_attach_options_t',['../structlxc__attach__options__t.html',1,'']]],
  ['lxc_5fcontainer',['lxc_container',['../structlxc__container.html',1,'']]],
  ['lxc_5flock',['lxc_lock',['../structlxc__lock.html',1,'']]],
  ['lxc_5fsnapshot',['lxc_snapshot',['../structlxc__snapshot.html',1,'']]]
];
