var searchData=
[
  ['may_5fcontrol',['may_control',['../structlxc__container.html#acdae241f1e3aca34fc8e977a0988c164',1,'lxc_container']]]
];
