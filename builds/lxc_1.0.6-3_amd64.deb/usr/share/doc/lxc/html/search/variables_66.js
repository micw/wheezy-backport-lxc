var searchData=
[
  ['f',['f',['../structlxc__lock.html#ac8b3e4d5bc4f01df592c97d4e1e38275',1,'lxc_lock']]],
  ['fd',['fd',['../structlxc__lock.html#a6cdb7cc026ad113cab26ab4272d9277c',1,'lxc_lock']]],
  ['fname',['fname',['../structlxc__lock.html#ab055e9e7e82d472f1c245d5a1ad7289d',1,'lxc_lock']]],
  ['free',['free',['../structlxc__snapshot.html#a3e1d2bfb57c16fc9f2845909f00ef8c0',1,'lxc_snapshot']]],
  ['freeze',['freeze',['../structlxc__container.html#a22ce4f38b3d23b932f77daccedc594d2',1,'lxc_container']]],
  ['fssize',['fssize',['../structbdev__specs.html#acd32f33fcd202f83f604cf6c527c6ce3',1,'bdev_specs']]],
  ['fstype',['fstype',['../structbdev__specs.html#a85413f21ad3fd3ed9f6c2cb64f02154e',1,'bdev_specs']]]
];
