var searchData=
[
  ['u',['u',['../structlxc__lock.html#a6a5a7f7802a1ec550eeef5353605c3e8',1,'lxc_lock']]],
  ['uid',['uid',['../structlxc__attach__options__t.html#a8a62e9318622bc396fdd24ab1a89bf60',1,'lxc_attach_options_t']]],
  ['unfreeze',['unfreeze',['../structlxc__container.html#af5fea8c09266fc5756c3b210e7bbc1b0',1,'lxc_container']]]
];
