var searchData=
[
  ['zfsroot',['zfsroot',['../structbdev__specs.html#a7109f002a6043168f964b643e423537b',1,'bdev_specs']]]
];
