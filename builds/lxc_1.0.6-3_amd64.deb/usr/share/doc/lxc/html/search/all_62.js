var searchData=
[
  ['bdev_5fspecs',['bdev_specs',['../structbdev__specs.html',1,'']]]
];
