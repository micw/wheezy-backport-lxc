var searchData=
[
  ['env_5fpolicy',['env_policy',['../structlxc__attach__options__t.html#af29f3d950ab011d4eac037ec25897f10',1,'lxc_attach_options_t']]],
  ['error_5fnum',['error_num',['../structlxc__container.html#aad1307b63ded0ac82e7a0adc06969dd8',1,'lxc_container']]],
  ['error_5fstring',['error_string',['../structlxc__container.html#a2fbfcf120528886aec7178e4d3631cba',1,'lxc_container']]],
  ['extra_5fenv_5fvars',['extra_env_vars',['../structlxc__attach__options__t.html#af776acab82e751f7d70d099016f4379e',1,'lxc_attach_options_t']]],
  ['extra_5fkeep_5fenv',['extra_keep_env',['../structlxc__attach__options__t.html#a38f07744e08a62c6d1550a2a77faf02c',1,'lxc_attach_options_t']]]
];
