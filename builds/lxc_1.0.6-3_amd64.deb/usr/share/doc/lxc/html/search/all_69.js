var searchData=
[
  ['init_5fpid',['init_pid',['../structlxc__container.html#ab5ce434297ed79a3877fae6139363455',1,'lxc_container']]],
  ['initial_5fcwd',['initial_cwd',['../structlxc__attach__options__t.html#ab6a000a4ac27f2ec3d861c55499eaff2',1,'lxc_attach_options_t']]],
  ['is_5fdefined',['is_defined',['../structlxc__container.html#ae21648c51038547f0bea5e7c12bc454d',1,'lxc_container']]],
  ['is_5frunning',['is_running',['../structlxc__container.html#add89060edc6bc4441fc273c5f4edb04e',1,'lxc_container']]]
];
