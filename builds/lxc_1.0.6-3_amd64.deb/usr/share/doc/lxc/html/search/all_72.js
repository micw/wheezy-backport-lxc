var searchData=
[
  ['reboot',['reboot',['../structlxc__container.html#ab2b0a7d1dc40fdb45ed5453b8bae042f',1,'lxc_container']]],
  ['remove_5fdevice_5fnode',['remove_device_node',['../structlxc__container.html#aa794f6d65734715bc7218b80df575f9c',1,'lxc_container']]],
  ['rename',['rename',['../structlxc__container.html#aef3055dc532eb49a48ab60e4b3097361',1,'lxc_container']]]
];
