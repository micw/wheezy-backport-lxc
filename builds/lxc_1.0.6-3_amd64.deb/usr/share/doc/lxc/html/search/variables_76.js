var searchData=
[
  ['vg',['vg',['../structbdev__specs.html#a78ae414b79b32bbc987e52b428aca6aa',1,'bdev_specs']]]
];
